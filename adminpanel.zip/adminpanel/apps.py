from django.apps import AppConfig


class AdminpanalConfig(AppConfig):
    name = 'adminpanal'
